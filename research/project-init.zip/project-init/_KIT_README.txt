PROJECT-INIT KIT
================

This directory is a starter template for new Python projects. It is opinionated
toward backend automation work in security-sensitive environments (DoW, federal,
or large-enterprise) running on Python 3.11-3.14, targeting CLI today and
Azure Functions tomorrow.

HOW TO USE
----------

1. Copy this entire directory tree to your new project location.
2. Rename the {{project_name}} package directory to your actual project name
   (lowercase, underscores, no hyphens).
3. Find-and-replace {{ project_name }} across all files with the same name.
4. Find-and-replace {{ PROJECT_NAME }} (upper-case form, used in a few places)
   with the upper-case form of the same name.
5. Delete this file (_KIT_README.txt).
6. Edit docs/README.txt for your actual project.
7. Run: python tasks.py init

PHILOSOPHY
----------

The kit defends against three specific failures:

  1. Six months from now, you (or a successor) cannot remember why the code
     is the way it is. Defended by: ADRs, ENGINEERING_GUIDE.txt, ARCHITECTURE.txt,
     extensive docstrings, structured logging.

  2. The code passes a security review or ATO package. Defended by:
     bandit + pip-audit in CI, SBOM generation, FIPS-aware crypto choices,
     pinned release manifests, compliance-mapping appendix in docs.

  3. The code installs and runs on an air-gapped target with one user
     who has Python and a wheelhouse. Defended by: requirements.txt for
     direct dependencies, requirements-lock.txt + wheelhouse for shipping,
     install guide that assumes nothing.

WHAT THIS KIT INTENTIONALLY DOES NOT INCLUDE
--------------------------------------------

  - uv, poetry, pdm, ruff: stdlib-adjacent Python toolchain only.
  - pre-commit framework: tasks.py runs all checks; no extra framework.
  - cookiecutter: copy-and-edit is simpler than templating until it isn't.
  - Makefile: cannot rely on make on locked-down Windows desktops.
  - pytest: unittest is stdlib and sufficient for current work.

DIRECTORY OVERVIEW
------------------

  bin/                       Entry-point scripts. One file, runnable directly.
  {{project_name}}/          The library package. Imported by bin/ scripts.
  test/unit/                 unittest test cases.
  test/integration/          Integration tests against real systems.
  test/robot/                Robot Framework acceptance tests (when needed).
  docs/                      All documentation. .txt for printability.
  docs/adr/                  Architecture Decision Records.
  docs/templates/            Templates for new ADRs, NFRs, etc.
  web/                       HTML templates and static assets (if applicable).
  .github/workflows/         GitHub Actions CI definitions.
  .gitlab/                   GitLab CI definitions (.gitlab-ci.yml at root).
  tasks.py                   Cross-platform task runner. python tasks.py help.
  pyproject.toml             Tool configurations (black, mypy, etc.).
  requirements.txt           Direct dependencies, loosely bounded.
  requirements_dev.txt       Dev/test/quality dependencies.
  requirements-lock.txt      Generated. Pinned release manifest. Do not edit.
