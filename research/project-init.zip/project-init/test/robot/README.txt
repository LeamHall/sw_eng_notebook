test/robot/
===========

Robot Framework acceptance tests live here. The directory is reserved
from project init even when no .robot files exist yet, so adding the
first acceptance test is friction-free.

To start using Robot Framework:

  1. Uncomment robotframework in requirements_dev.txt and re-run
     python tasks.py init.
  2. Create your first test file: test/robot/smoke.robot
  3. Add a task to tasks.py:

         def task_robot():
             """Run Robot Framework acceptance tests."""
             run([python(), "-m", "robot", "test/robot"])

  4. Document the test scope in this directory (what is covered by
     RF, what is covered by unittest).

When to use Robot Framework versus unittest:

  - unittest: behavior of Python code at the function and module level.
    Fast, mockable, no infrastructure.

  - Robot Framework: end-to-end behavior described in keyword form.
    Slower, exercises real flows, readable by non-developers. Useful
    when the acceptance criteria come from a non-developer stakeholder
    or when the test is best expressed as "given/when/then" rather
    than "assertEqual".
