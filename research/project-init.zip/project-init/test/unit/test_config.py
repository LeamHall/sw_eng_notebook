# -----------------------------------------------------------------------------
# test/unit/test_config.py
#
# Example unit test demonstrating the project's testing conventions:
#   - unittest from the standard library.
#   - One TestCase class per module under test, named TestXxx.
#   - Test method names describe what is being verified, not the method
#     being called: test_input_dir_must_exist, not test_post_init.
#   - tempfile / Path used for any disk-touching tests.
#   - No network in unit tests. No real database in unit tests.
# -----------------------------------------------------------------------------

import tempfile
import unittest
from pathlib import Path

from {{ project_name }}.config import Config, ConfigError


class TestConfig(unittest.TestCase):

    def setUp(self):
        # A real directory that exists for the duration of one test.
        self._tmp = tempfile.TemporaryDirectory()
        self.input_dir = Path(self._tmp.name)
        self.output_db = self.input_dir / "out.db"

    def tearDown(self):
        self._tmp.cleanup()

    def test_config_loads_with_valid_inputs(self):
        cfg = Config.load(
            input_dir=self.input_dir,
            output_db=self.output_db,
        )
        self.assertEqual(cfg.input_dir, self.input_dir)
        self.assertEqual(cfg.log_level, "INFO")
        self.assertFalse(cfg.dry_run)

    def test_input_dir_must_exist(self):
        nonexistent = self.input_dir / "does_not_exist"
        with self.assertRaises(ConfigError):
            Config.load(input_dir=nonexistent, output_db=self.output_db)

    def test_invalid_log_level_rejected(self):
        with self.assertRaises(ConfigError):
            Config.load(
                input_dir=self.input_dir,
                output_db=self.output_db,
                log_level="LOUDER",
            )

    def test_secrets_are_not_in_repr(self):
        cfg = Config.load(
            input_dir=self.input_dir,
            output_db=self.output_db,
        )
        # If a token were set, the dataclass repr=False on the field
        # would keep it out of __repr__. Verify the contract here.
        text = repr(cfg)
        self.assertNotIn("api_token", text)


if __name__ == "__main__":
    unittest.main()
