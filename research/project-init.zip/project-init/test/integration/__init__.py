# Marker file. Integration tests are slow and may touch real systems.
# Run with: python tasks.py test-integration
