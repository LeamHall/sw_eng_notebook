# -----------------------------------------------------------------------------
# {{ project_name }}/__init__.py
#
# Package marker for {{ project_name }}. Keep this file small. Re-export only
# what callers should treat as the public API.
# -----------------------------------------------------------------------------

__version__ = "0.1.0"

# Example public re-exports (uncomment as the API stabilizes):
# from {{ project_name }}.pipeline import run
# from {{ project_name }}.config import Config

__all__ = [
    "__version__",
    # "run",
    # "Config",
]
