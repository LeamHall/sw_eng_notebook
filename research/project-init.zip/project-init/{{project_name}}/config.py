# -----------------------------------------------------------------------------
# {{ project_name }}/config.py
#
# Configuration loading and validation. The Config dataclass is the only
# configuration object the rest of the application sees. Build it once,
# at program start, then pass it down. Do not read os.environ or open
# config files outside this module.
#
# Secrets policy:
#   - Secrets never appear in code.
#   - Secrets never appear in logs (Config.__repr__ masks them).
#   - Secrets come from environment variables or a config file outside
#     the repo. The path to the config file is itself non-secret.
# -----------------------------------------------------------------------------

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


_ENV_PREFIX = "{{ PROJECT_NAME }}_"


class ConfigError(Exception):
    """Raised when configuration is missing, invalid, or contradictory."""


@dataclass(frozen=True)
class Config:
    """Application configuration.

    All fields are immutable after construction. Construct via
    Config.load() or Config.from_args(); do not instantiate directly
    unless you have already validated the values.
    """

    # Example fields. Replace with project-specific configuration.
    input_dir: Path
    output_db: Path
    log_level: str = "INFO"
    log_file: Optional[Path] = None
    dry_run: bool = False

    # Secrets are stored separately and masked on repr.
    api_token: Optional[str] = field(default=None, repr=False)

    def __post_init__(self) -> None:
        # Validate at construction so downstream code never has to.
        if not isinstance(self.input_dir, Path):
            raise ConfigError("input_dir must be a Path")
        if not self.input_dir.is_dir():
            raise ConfigError(
                "input_dir does not exist or is not a directory: {0}".format(
                    self.input_dir
                )
            )
        if self.log_level.upper() not in {
            "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"
        }:
            raise ConfigError("log_level is invalid: {0}".format(self.log_level))

    @classmethod
    def load(
        cls,
        input_dir: Path,
        output_db: Path,
        log_level: str = "INFO",
        log_file: Optional[Path] = None,
        dry_run: bool = False,
    ) -> "Config":
        """Build a Config from explicit arguments and environment overrides.

        CLI arguments take precedence over environment variables. The
        environment variables follow the convention {{ PROJECT_NAME }}_<FIELD>.
        """
        api_token = os.environ.get(_ENV_PREFIX + "API_TOKEN")

        return cls(
            input_dir=input_dir,
            output_db=output_db,
            log_level=log_level,
            log_file=log_file,
            dry_run=dry_run,
            api_token=api_token,
        )
