# -----------------------------------------------------------------------------
# {{ project_name }}/pipeline.py
#
# Top-level orchestration. The run() function is the single entry point
# that bin/{{ project_name }}.py calls into. Steps are functions; the
# pipeline owns the order.
#
# Error handling policy: fail loud, stop cold. Validate all inputs before
# producing any side effect. Do not catch broad exceptions; let them
# propagate to the CLI, which logs and exits non-zero.
# -----------------------------------------------------------------------------

from {{ project_name }}.config import Config
from {{ project_name }}.logging_setup import get_logger

logger = get_logger(__name__)


class PipelineError(Exception):
    """Raised when the pipeline detects a condition that requires aborting
    before any side effects occur. Distinct from unexpected exceptions.
    """


def run(config: Config) -> int:
    """Execute the pipeline.

    Parameters
    ----------
    config : Config
        Validated application configuration.

    Returns
    -------
    int
        Exit code. 0 on success. Non-zero values map to README.txt
        EXIT CODES section.

    Notes
    -----
    Side effects (writes, network calls) happen only after the validation
    phase completes successfully. Any failure before that point means no
    output has been produced.
    """
    logger.info("pipeline_start dry_run=%s", config.dry_run)

    # Phase 1: read and validate everything. No side effects yet.
    # records = _read_inputs(config)
    # _validate(records, config)

    # Phase 2: transform. Pure functions, still no side effects.
    # transformed = _transform(records, config)

    # Phase 3: side effects. After this point partial state is possible
    # only if an exception is raised; in that case the program exits
    # non-zero and the caller is expected to inspect the partial state.
    if config.dry_run:
        logger.info("pipeline_dry_run_complete records=%d", 0)
        return 0

    # _write(transformed, config)
    logger.info("pipeline_complete records=%d", 0)
    return 0
