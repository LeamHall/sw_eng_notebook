# -----------------------------------------------------------------------------
# {{ project_name }}/logging_setup.py
#
# Configures the root logger for the application. Called exactly once,
# from the CLI entry point in bin/{{ project_name }}.py.
#
# Conventions enforced here:
#   - Module loggers obtained with logging.getLogger(__name__).
#   - Format string with timestamp, level, logger name, message.
#   - Structured key=value fields for parseability by log aggregators.
#   - %-style format in log calls, not .format() or f-strings.
#
# NIST 800-53 SA-15 (Logging Syntax, Release 5.2.0) is addressed by the
# structured format below. AU-2 and AU-3 are supported by ensuring
# timestamp, level, source, and message are always present.
# -----------------------------------------------------------------------------

import logging
import logging.handlers
import os
import sys
from pathlib import Path
from typing import Optional


# Format chosen for human readability and parseability.
# Example output:
#   2026-05-25T17:51:03Z INFO {{ project_name }}.pipeline message=...
_DEFAULT_FORMAT = (
    "%(asctime)s %(levelname)s %(name)s "
    "pid=%(process)d msg=%(message)s"
)
_DEFAULT_DATEFMT = "%Y-%m-%dT%H:%M:%SZ"


def configure_logging(
    level: str = "INFO",
    log_file: Optional[Path] = None,
) -> None:
    """Configure root logging.

    Parameters
    ----------
    level : str
        Log level name. INFO is the default. Can be overridden by the
        environment variable {{ PROJECT_NAME }}_LOG_LEVEL.
    log_file : Optional[Path]
        If provided, log records are also written to this file using a
        rotating file handler. The console handler is always active.

    Notes
    -----
    UTC timestamps are used to keep logs consistent across deployment
    timezones. This matters for log aggregation and incident timelines.
    """
    env_level = os.environ.get("{{ PROJECT_NAME }}_LOG_LEVEL")
    effective_level = (env_level or level).upper()

    root = logging.getLogger()
    root.setLevel(effective_level)

    # Clear any handlers a library may have added.
    for h in list(root.handlers):
        root.removeHandler(h)

    formatter = logging.Formatter(
        fmt=_DEFAULT_FORMAT,
        datefmt=_DEFAULT_DATEFMT,
    )
    # Use UTC.
    formatter.converter = _utc_converter

    console = logging.StreamHandler(stream=sys.stderr)
    console.setFormatter(formatter)
    root.addHandler(console)

    if log_file is not None:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            filename=str(log_file),
            maxBytes=10 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)


def _utc_converter(timestamp):
    """Convert a log record timestamp to UTC for the formatter."""
    import time
    return time.gmtime(timestamp)


def get_logger(name: str) -> logging.Logger:
    """Return a module-level logger.

    Use this in module top-level code:

        from {{ project_name }}.logging_setup import get_logger
        logger = get_logger(__name__)

    The wrapper exists so logger acquisition stays consistent across
    the codebase even if the underlying mechanism changes.
    """
    return logging.getLogger(name)
