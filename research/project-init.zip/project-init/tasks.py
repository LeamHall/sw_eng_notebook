#!/usr/bin/env python3
# -----------------------------------------------------------------------------
# tasks.py
#
# Cross-platform task runner for {{ project_name }}. Uses only the Python
# standard library so it works anywhere Python 3.11+ is available, including
# on locked-down Windows desktops where make cannot be installed.
#
# Usage:
#     python tasks.py help
#     python tasks.py <task-name>
#
# Tasks are functions named task_<name>(). Add a new task by adding a function.
# The docstring of the function is shown by 'help'.
# -----------------------------------------------------------------------------

import argparse
import inspect
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKAGE = "{{ project_name }}"     # adjust if the package is renamed
BIN_DIR = ROOT / "bin"
TEST_DIR = ROOT / "test"


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def run(cmd, check=True):
    """Run a command list, echo it, and return the CompletedProcess."""
    print(">>> {0}".format(" ".join(cmd)))
    return subprocess.run(cmd, check=check)


def run_ok(cmd):
    """Run a command, return True on success without raising."""
    print(">>> {0}".format(" ".join(cmd)))
    return subprocess.run(cmd, check=False).returncode == 0


def python():
    """Return the path to the current Python interpreter."""
    return sys.executable


# -----------------------------------------------------------------------------
# Tasks
# -----------------------------------------------------------------------------

def task_help():
    """Show available tasks."""
    print("Available tasks:")
    print()
    tasks = sorted(
        (name[5:], fn)
        for name, fn in globals().items()
        if name.startswith("task_") and callable(fn)
    )
    width = max(len(name) for name, _ in tasks)
    for name, fn in tasks:
        doc = (fn.__doc__ or "").strip().splitlines()
        first = doc[0] if doc else ""
        print("  {0}  {1}".format(name.ljust(width), first))
    print()
    print("Run a task with: python tasks.py <task-name>")


def task_init():
    """Install dev and runtime dependencies into the active venv."""
    run([python(), "-m", "pip", "install", "--upgrade", "pip"])
    run([python(), "-m", "pip", "install", "-r", "requirements.txt"])
    run([python(), "-m", "pip", "install", "-r", "requirements_dev.txt"])


def task_format():
    """Auto-format code with black (line length 79)."""
    run([python(), "-m", "black", "-l", "79", PACKAGE, "bin", "test", "tasks.py"])


def task_format_check():
    """Check formatting without modifying files."""
    run([python(), "-m", "black", "-l", "79", "--check",
         PACKAGE, "bin", "test", "tasks.py"])


def task_lint():
    """Run flake8 and vulture."""
    ok = True
    ok = run_ok([python(), "-m", "flake8", PACKAGE, "bin", "test", "tasks.py"]) and ok
    ok = run_ok([python(), "-m", "vulture", PACKAGE, "bin",
                 "--min-confidence", "80"]) and ok
    if not ok:
        sys.exit(1)


def task_typecheck():
    """Run mypy."""
    run([python(), "-m", "mypy", PACKAGE, "bin"])


def task_security():
    """Run bandit and pip-audit. Outputs are kept for audit."""
    reports = ROOT / "build" / "security"
    reports.mkdir(parents=True, exist_ok=True)

    # bandit: scan source, write JSON for archival, also print summary.
    bandit_json = reports / "bandit.json"
    run([python(), "-m", "bandit", "-r", PACKAGE, "bin",
         "-f", "json", "-o", str(bandit_json)], check=False)
    run([python(), "-m", "bandit", "-r", PACKAGE, "bin"], check=False)

    # pip-audit: scan installed packages against vulnerability db.
    pipaudit_json = reports / "pip-audit.json"
    run([python(), "-m", "pip_audit",
         "-r", "requirements.txt",
         "-f", "json", "-o", str(pipaudit_json)], check=False)
    run([python(), "-m", "pip_audit", "-r", "requirements.txt"], check=False)

    print()
    print("Security reports written to: {0}".format(reports))


def task_test():
    """Run unit tests (fast, no network/disk dependencies)."""
    run([python(), "-m", "unittest", "discover",
         "-s", "test/unit", "-p", "test_*.py", "-v"])


def task_test_integration():
    """Run integration tests (slow, may touch network/disk/db)."""
    run([python(), "-m", "unittest", "discover",
         "-s", "test/integration", "-p", "test_*.py", "-v"])


def task_test_all():
    """Run unit and integration tests."""
    task_test()
    task_test_integration()


def task_coverage():
    """Run unit tests under coverage and produce a report."""
    run([python(), "-m", "coverage", "run", "-m", "unittest", "discover",
         "-s", "test/unit", "-p", "test_*.py"])
    run([python(), "-m", "coverage", "report", "-m"])
    run([python(), "-m", "coverage", "html"])
    html = ROOT / "htmlcov" / "index.html"
    print()
    print("Coverage HTML report: {0}".format(html))


def task_check():
    """Run all quality gates: format-check, lint, typecheck, security, test."""
    task_format_check()
    task_lint()
    task_typecheck()
    task_security()
    task_test()


def task_sbom():
    """Generate a CycloneDX SBOM from the current environment."""
    out = ROOT / "build" / "sbom"
    out.mkdir(parents=True, exist_ok=True)
    sbom_json = out / "{0}-sbom.json".format(PACKAGE)
    run([python(), "-m", "cyclonedx_py", "environment",
         "-o", str(sbom_json)])
    print()
    print("SBOM written to: {0}".format(sbom_json))


def task_lock():
    """Regenerate requirements-lock.txt from requirements.txt with hashes.

    Run this on a connected machine before producing a release. The
    resulting file is the air-gap shipping manifest.
    """
    # pip-compile from pip-tools, installed via requirements_dev.txt.
    run([python(), "-m", "piptools", "compile",
         "--generate-hashes",
         "--output-file", "requirements-lock.txt",
         "requirements.txt"])


def task_wheelhouse():
    """Build a wheelhouse for air-gapped install.

    Downloads all wheels referenced by requirements-lock.txt for the
    current Python/platform. The wheelhouse plus the source plus the
    lock file is the release bundle.
    """
    wheels = ROOT / "wheelhouse"
    wheels.mkdir(exist_ok=True)
    run([python(), "-m", "pip", "download",
         "-r", "requirements-lock.txt",
         "-d", str(wheels),
         "--require-hashes"])
    print()
    print("Wheelhouse built at: {0}".format(wheels))


def task_clean():
    """Remove build artifacts and caches."""
    targets = [
        "build", "dist", "htmlcov", ".mypy_cache",
        ".coverage", "wheelhouse",
    ]
    for t in targets:
        p = ROOT / t
        if p.is_dir():
            shutil.rmtree(p)
            print("removed dir : {0}".format(p))
        elif p.is_file():
            p.unlink()
            print("removed file: {0}".format(p))
    # __pycache__ dirs scattered throughout the tree
    for pyc in ROOT.rglob("__pycache__"):
        shutil.rmtree(pyc)
        print("removed dir : {0}".format(pyc))


# -----------------------------------------------------------------------------
# Entry point
# -----------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Cross-platform task runner. Run 'help' to list tasks.",
    )
    parser.add_argument("task", nargs="?", default="help",
                        help="Task name (default: help)")
    args = parser.parse_args()

    fn_name = "task_{0}".format(args.task.replace("-", "_"))
    fn = globals().get(fn_name)
    if not callable(fn):
        print("Unknown task: {0}".format(args.task), file=sys.stderr)
        print("Run 'python tasks.py help' to list available tasks.",
              file=sys.stderr)
        sys.exit(2)
    fn()


if __name__ == "__main__":
    main()
