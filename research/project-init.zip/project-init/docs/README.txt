{{ PROJECT_NAME }}
=====================================

One-line description of what this tool does and who runs it.


WHAT IT DOES
------------

A short paragraph, in plain language, that a non-developer can read and
understand the purpose of this tool. Avoid jargon. Say what the input is,
what the output is, and who would care.


REQUIREMENTS
------------

  - Python 3.11 or later (tested through 3.14)
  - The contents of requirements.txt installed into the active environment
  - {{ List any external services, files, network access, credentials }}


INSTALL (CONNECTED ENVIRONMENT)
-------------------------------

  1. Clone or copy this directory to your workstation.
  2. Create and activate a virtual environment:
       python -m venv .venv
       .venv\Scripts\activate           (Windows)
       source .venv/bin/activate         (Linux/macOS)
  3. Install dependencies:
       python -m pip install --upgrade pip
       python -m pip install -r requirements.txt
  4. Verify the install:
       python bin/{{ project_name }}.py --help


INSTALL (AIR-GAPPED ENVIRONMENT)
--------------------------------

  1. Obtain the release bundle: {{ project_name }}-X.Y.Z.zip
     This bundle contains the source plus a wheelhouse/ directory of all
     dependency wheels for the target Python version and platform.
  2. Extract the bundle.
  3. Create and activate a virtual environment (see above).
  4. Install dependencies from the wheelhouse:
       python -m pip install --no-index --find-links wheelhouse -r requirements-lock.txt
  5. Verify the install:
       python bin/{{ project_name }}.py --help


USAGE
-----

Show all options:
    python bin/{{ project_name }}.py --help

Common invocations:
    {{ Example 1: typical case, with explanation of what it produces }}
    {{ Example 2: edge case, with explanation }}


CONFIGURATION
-------------

{{ Describe configuration file location, environment variables, and any
   secrets handling. If config is via CLI args only, say so. }}


OUTPUT
------

{{ Describe what files, log entries, or external-system effects this tool
   produces. Be explicit about side effects: writes to disk, sends emails,
   modifies databases, etc. }}


LOGGING
-------

Logs are written to:
  - Console (stderr) by default
  - {{ logfile location if applicable }}

Log level is controlled by the --log-level argument or the
{{ PROJECT_NAME }}_LOG_LEVEL environment variable. Default is INFO.


EXIT CODES
----------

  0    Success.
  1    Generic error. See log output.
  2    Invalid arguments or configuration.
  3    Input data validation failure (the tool stopped before making changes).
  4    External system failure (database, API, file system).


KNOWN LIMITATIONS
-----------------

{{ List anything the user must know up front: rate limits, file size limits,
   unsupported input shapes, etc. }}


WHERE TO READ NEXT
------------------

  docs/ENGINEERING_GUIDE.txt    For new developers joining this project.
  docs/ARCHITECTURE.txt         How the pieces fit together.
  docs/adr/                     Why specific decisions were made.
  CHANGELOG.txt                 What changed between releases.


CONTACT
-------

{{ Your name, your team, where to file issues, where to ask questions }}
